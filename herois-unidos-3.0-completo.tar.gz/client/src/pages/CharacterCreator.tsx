import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { races } from "@/lib/gameData";
import { classes } from "@/lib/classesData";
import { backgrounds } from "@/lib/backgroundsData";
import { skills } from "@/lib/skillsData";
import { ChevronLeft, Download, ChevronRight, User, Shield, Zap, BookOpen } from "lucide-react";

interface Character {
  name: string;
  race: string;
  subRace: string;
  class: string;
  background: string;
  image: string | null;
  attributes: {
    strength: number;
    dexterity: number;
    intelligence: number;
    charisma: number;
    constitution: number;
    will: number;
  };
  selectedSkills: string[];
  selectedTalents: string[];
}

export default function CharacterCreator() {
  const [step, setStep] = useState<number>(1);
  const [character, setCharacter] = useState<Character>({
    name: "",
    race: races[0]?.id || "",
    subRace: "",
    class: classes[0]?.id || "",
    background: backgrounds[0]?.id || "",
    image: null,
    attributes: {
      strength: 10,
      dexterity: 10,
      intelligence: 10,
      charisma: 10,
      constitution: 10,
      will: 10,
    },
    selectedSkills: [],
    selectedTalents: [],
  });

  const selectedRace = races.find((r) => r.id === character.race);
  const selectedClass = classes.find((c) => c.id === character.class);
  const selectedBackground = backgrounds.find((b) => b.id === character.background);

  const handleAttributeChange = (attr: keyof Character["attributes"], value: number) => {
    const newAttributes = { ...character.attributes };
    newAttributes[attr] = Math.max(1, Math.min(30, value));
    setCharacter({ ...character, attributes: newAttributes });
  };

  const toggleSkill = (skillId: string) => {
    const newSkills = character.selectedSkills.includes(skillId)
      ? character.selectedSkills.filter((s) => s !== skillId)
      : [...character.selectedSkills, skillId].slice(0, 4);
    setCharacter({ ...character, selectedSkills: newSkills });
  };

  const calculateModifier = (attributeValue: number) => {
    return Math.floor((attributeValue - 10) / 2);
  };

  const calculateHP = () => {
    const baseHP = 20;
    const conBonus = calculateModifier(character.attributes.constitution);
    return Math.max(1, baseHP + conBonus + 10);
  };

  const calculateCA = () => {
    const baseDex = calculateModifier(character.attributes.dexterity);
    return 10 + baseDex;
  };

  const downloadCharacter = () => {
    const charData = {
      ...character,
      hp: calculateHP(),
      ca: calculateCA(),
      modifiers: {
        strength: calculateModifier(character.attributes.strength),
        dexterity: calculateModifier(character.attributes.dexterity),
        intelligence: calculateModifier(character.attributes.intelligence),
        charisma: calculateModifier(character.attributes.charisma),
        constitution: calculateModifier(character.attributes.constitution),
        will: calculateModifier(character.attributes.will),
      },
    };
    const json = JSON.stringify(charData, null, 2);
    const blob = new Blob([json], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${character.name || "personagem"}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white">
      <header className="border-b border-slate-700 bg-slate-900/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container py-4 flex items-center justify-between">
          <Link href="/">
            <Button variant="ghost" size="sm" className="text-slate-300">
              <ChevronLeft className="mr-2" />
              Voltar
            </Button>
          </Link>
          <h1 className="text-2xl font-bold">👤 Criador de Personagem</h1>
          <div className="text-sm text-slate-400">Passo {step} de 5</div>
        </div>
      </header>

      <div className="container py-12">
        {step === 1 && (
          <div className="max-w-2xl mx-auto">
            <Card className="bg-slate-800 border-slate-700 p-8">
              <h2 className="text-3xl font-bold mb-6">Escolha sua Raça</h2>
              <div className="space-y-3 mb-8">
                {races.map((race) => (
                  <button
                    key={race.id}
                    onClick={() => setCharacter({ ...character, race: race.id, subRace: "" })}
                    className={`w-full text-left p-4 rounded-lg border-2 transition flex items-center gap-4 ${
                      character.race === race.id
                        ? "bg-blue-600 border-blue-500"
                        : "bg-slate-700 border-slate-600 hover:border-blue-500"
                    }`}
                  >
                    <span className="text-3xl">{race.icon}</span>
                    <div>
                      <p className="font-bold">{race.name}</p>
                      <p className="text-xs text-slate-400">{race.examples[0]}</p>
                    </div>
                  </button>
                ))}
              </div>
              <Button onClick={() => setStep(2)} className="w-full bg-blue-600 hover:bg-blue-700 py-3">
                Próximo <ChevronRight className="ml-2" />
              </Button>
            </Card>
          </div>
        )}

        {step === 2 && (
          <div className="max-w-2xl mx-auto">
            <Card className="bg-slate-800 border-slate-700 p-8">
              <h2 className="text-3xl font-bold mb-6">Escolha sua Classe</h2>
              <div className="space-y-3 mb-8">
                {classes.map((cls) => (
                  <button
                    key={cls.id}
                    onClick={() => setCharacter({ ...character, class: cls.id })}
                    className={`w-full text-left p-4 rounded-lg border-2 transition ${
                      character.class === cls.id
                        ? "bg-green-600 border-green-500"
                        : "bg-slate-700 border-slate-600 hover:border-green-500"
                    }`}
                  >
                    <p className="font-bold">{cls.icon} {cls.name}</p>
                    <p className="text-xs text-slate-400 mt-1">{cls.description}</p>
                  </button>
                ))}
              </div>
              <div className="flex gap-4">
                <Button onClick={() => setStep(1)} variant="outline" className="flex-1 border-slate-600">Voltar</Button>
                <Button onClick={() => setStep(3)} className="flex-1 bg-blue-600 hover:bg-blue-700">Próximo</Button>
              </div>
            </Card>
          </div>
        )}

        {step === 3 && (
          <div className="max-w-2xl mx-auto">
            <Card className="bg-slate-800 border-slate-700 p-8">
              <h2 className="text-3xl font-bold mb-6">Escolha seu Antecedente</h2>
              <div className="space-y-3 mb-8 max-h-[400px] overflow-y-auto pr-2">
                {backgrounds.map((bg) => (
                  <button
                    key={bg.id}
                    onClick={() => setCharacter({ ...character, background: bg.id })}
                    className={`w-full text-left p-4 rounded-lg border-2 transition ${
                      character.background === bg.id
                        ? "bg-orange-600 border-orange-500"
                        : "bg-slate-700 border-slate-600 hover:border-orange-500"
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <span className="text-2xl">{bg.emoji}</span>
                      <div>
                        <p className="font-bold">{bg.name}</p>
                        <p className="text-xs text-slate-400">{bg.specialAbility}</p>
                      </div>
                    </div>
                  </button>
                ))}
              </div>
              <div className="flex gap-4">
                <Button onClick={() => setStep(2)} variant="outline" className="flex-1 border-slate-600">Voltar</Button>
                <Button onClick={() => setStep(4)} className="flex-1 bg-blue-600 hover:bg-blue-700">Próximo</Button>
              </div>
            </Card>
          </div>
        )}

        {step === 4 && (
          <div className="max-w-4xl mx-auto">
            <Card className="bg-slate-800 border-slate-700 p-8">
              <h2 className="text-3xl font-bold mb-6">Atributos e Perícias</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
                <div className="space-y-4">
                  {Object.entries(character.attributes).map(([attr, value]) => (
                    <div key={attr}>
                      <div className="flex justify-between text-sm mb-1">
                        <label className="capitalize font-bold">{attr}</label>
                        <span className="text-blue-400 font-bold">{value} (Mod: {calculateModifier(value)})</span>
                      </div>
                      <input
                        type="range" min="1" max="30" value={value}
                        onChange={(e) => handleAttributeChange(attr as keyof Character["attributes"], parseInt(e.target.value))}
                        className="w-full accent-blue-500"
                      />
                    </div>
                  ))}
                </div>
                <div>
                  <h3 className="text-lg font-bold mb-4 flex items-center gap-2"><BookOpen size={18} /> Perícias (Selecione 4)</h3>
                  <div className="grid grid-cols-2 gap-2">
                    {skills.map((skill) => (
                      <button
                        key={skill.id}
                        onClick={() => toggleSkill(skill.id)}
                        className={`text-left p-2 rounded text-xs border transition ${
                          character.selectedSkills.includes(skill.id)
                            ? "bg-blue-600 border-blue-400 text-white"
                            : "bg-slate-700 border-slate-600 text-slate-400 hover:border-blue-400"
                        }`}
                      >
                        {skill.name}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
              <div className="flex gap-4">
                <Button onClick={() => setStep(3)} variant="outline" className="flex-1 border-slate-600">Voltar</Button>
                <Button onClick={() => setStep(5)} className="flex-1 bg-blue-600 hover:bg-blue-700">Próximo</Button>
              </div>
            </Card>
          </div>
        )}

        {step === 5 && (
          <div className="max-w-4xl mx-auto">
            <Card className="bg-slate-800 border-slate-700 p-8">
              <h2 className="text-3xl font-bold mb-6">Resumo do Personagem</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                <div className="space-y-4">
                  <div className="p-4 bg-slate-900 rounded-xl border border-slate-700">
                    <h3 className="text-xs font-bold text-slate-500 uppercase mb-2">Informações</h3>
                    <p className="text-lg font-bold">{selectedRace?.name}</p>
                    <p className="text-blue-400">{selectedClass?.name}</p>
                    <p className="text-orange-400 text-sm">{selectedBackground?.name}</p>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div className="p-3 bg-red-900/20 rounded-lg border border-red-500/20 text-center">
                      <div className="text-xs text-red-400">HP</div>
                      <div className="text-xl font-bold">{calculateHP()}</div>
                    </div>
                    <div className="p-3 bg-blue-900/20 rounded-lg border border-blue-500/20 text-center">
                      <div className="text-xs text-blue-400">CA</div>
                      <div className="text-xl font-bold">{calculateCA()}</div>
                    </div>
                  </div>
                </div>
                <div className="md:col-span-2 grid grid-cols-2 md:grid-cols-3 gap-3">
                  {Object.entries(character.attributes).map(([attr, value]) => (
                    <div key={attr} className="p-3 bg-slate-700/30 rounded-lg border border-slate-600">
                      <div className="text-[10px] uppercase text-slate-500">{attr}</div>
                      <div className="text-lg font-bold">{value}</div>
                      <div className="text-xs text-blue-400">Mod: {calculateModifier(value)}</div>
                    </div>
                  ))}
                </div>
              </div>
              <div className="flex gap-4">
                <Button onClick={() => setStep(4)} variant="outline" className="flex-1 border-slate-600">Voltar</Button>
                <Button onClick={downloadCharacter} className="flex-1 bg-green-600 hover:bg-green-700">
                  <Download className="mr-2" /> Salvar Ficha
                </Button>
              </div>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}
